define(['require','modules/settings_panel','panels/simpin/simpin'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');
  var SimPin = require('panels/simpin/simpin');

  return function ctor_simpin_panel() {
    return SettingsPanel({
      onInit: function(panel) {
        var elements = {};
        elements.simPinTmpl = panel.querySelector('.simpin-tmpl');
        elements.simPinContainer = panel.querySelector('.simpin-container');
        elements.simPinHeader = panel.querySelector('.simpin-header');

        var simpin = SimPin(elements);
        simpin.init();
      }
    });
  };
});
