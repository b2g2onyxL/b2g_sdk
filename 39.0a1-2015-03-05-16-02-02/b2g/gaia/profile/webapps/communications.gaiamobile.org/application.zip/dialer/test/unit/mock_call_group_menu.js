'use strict';

/* exported MockCallGroupMenu */

var MockCallGroupMenu = {
  show: function(contactId, phoneNumber, day, type) {}
};
