'use strict';
/* exported MockMatchingController */

var MockMatchingController = {
  merge: function(checkedContacts) {
    this.checkedContacts = checkedContacts;
  }
};
