/*
  Copyright 2012, Mozilla Foundation

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

'use strict';

/**
 * This is the basic prototype of LockScreen states.
 * Extend this prototype to implement your state.
 */
(function(exports) {
  var LockScreenBaseState = function() {};
  LockScreenBaseState.prototype.start = function() {
    return this;
  };
  LockScreenBaseState.prototype.transferOut = function() {
    return new Promise((resolve, reject) => {
      resolve();
    });
  };
  LockScreenBaseState.prototype.transferTo = function() {
    return new Promise((resolve, reject) => {
      resolve();
    });
  };
  exports.LockScreenBaseState = LockScreenBaseState;
})(window);

