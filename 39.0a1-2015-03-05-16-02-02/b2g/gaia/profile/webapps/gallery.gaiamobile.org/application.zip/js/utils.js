/* exported $ */
'use strict';

function $(id) { return document.getElementById(id); }
