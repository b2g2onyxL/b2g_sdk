/* global NotificationHandler */

'use strict';

(function() {
  NotificationHandler.init();
})();
